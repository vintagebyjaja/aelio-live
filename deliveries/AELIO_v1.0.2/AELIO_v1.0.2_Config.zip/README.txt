Read config/DREAM_BOX.md. Merge these changed headers with existing settings. Existing Auth/R2 secrets are unchanged; no new environment key is required. Build before owner-managed upload.
